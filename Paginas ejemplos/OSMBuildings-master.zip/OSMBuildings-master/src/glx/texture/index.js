
GLX.texture = {};
