### Fetch building details

~~~ javascript
osmb.on('pointerup', e => {
  if (e.target) {
    // fetch URL http://overpass-api.de/api/interpreter?data=[out:json];(way(e.target.id);node(w));out;
  }
});
~~~
